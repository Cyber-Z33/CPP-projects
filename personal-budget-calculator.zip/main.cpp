#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
    double monthlyIncome;
    double rent, food, transportation, entertainment, otherExpenses;
    double totalExpenses, remainingBalance, yearlyProjection;
    
    // User Input
    cout << "Monthly Budget Calculator\n";
    cout << "-------------------------\n";
    
    cout << "Enter monthly income: $";
    cin >> monthlyIncome;
    
    cout << "Enter rent expense: $";
    cin >> rent;
    
    cout << "Enter food expenses: $";
    cin >> food;
    
    cout << "Enter transportation expenses: $";
    cin >> transportation;
    
    cout << "Enter entertainment expenses: $";
    cin >> entertainment;
    
    cout << "Enter other expenses: $";
    cin >> otherExpenses;
    
    // Calculations
    totalExpenses = rent + food + transportation + entertainment + otherExpenses;
    remainingBalance = monthlyIncome - totalExpenses;
    yearlyProjection = remainingBalance * 12;
    
    // Output Formatting
    cout << fixed << setprecision(2);
    
    cout << "\n--- Monthly Budget Summary ---\n";
    cout << "Monthly Income: $" << monthlyIncome << endl;
    cout << "Total Expenses: $" << totalExpenses << endl;
    cout << "Remaining Balance: $" << remainingBalance << endl;
    
    // Budget Status
    if (remainingBalance > 0)
    {
        cout << "Status: Under Budget" << endl;
    }
    else if (remainingBalance < 0)
    {
        cout << "Status: Over Budget" << endl;
    }
    else
    {
        cout << "Status: Exactly Balanced" << endl;
    }
    
    // Extra Credit
    cout << "Projected Yearly Savings: $" << yearlyProjection << endl;
    
    return 0;
}