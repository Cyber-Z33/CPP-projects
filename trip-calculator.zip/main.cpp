#include <iostream>
#include <iomanip>
using namespace std;

// function calculate gas cost
double calculateGasCost(double miles, double mpg, double gasPrice)
{
    return (miles / mpg) * gasPrice;
}

// function to calculate food cost
double calculateFoodCost(int days, double foodPerDay)
{
    return days * foodPerDay;
}
// function to calculate hotel cost
double calculateHotelCost(int nights, double hotelPerNight)
{
    return nights * hotelPerNight;
}
int main()
{
    // variables
    double totalMiles, milesPerGallon, gasPrice;
    int travelDays;
    double foodBudgetPerDay;
    double hotelCostPerNight;
    int hotelNights;
    int people;
    
    // user input
    cout << "Road Trip Cost Estimator\n";
    cout << "------------------------\n";
    
    cout << "Enter total miles: ";
    cin >> totalMiles;
    
    cout << "Enter miles per gallon: ";
    cin >> milesPerGallon;
    
    cout << "Enter gas price per gallon: ";
    cin >> gasPrice;
    
    cout << "Enter number of travel days: ";
    cin >> travelDays;
    
    cout << "Enter food budget per day: ";
    cin >> foodBudgetPerDay;
    
    cout << "Enter hotel cost per night: ";
    cin >> hotelCostPerNight;
    
    cout << "Enter number of hotel nights: ";
    cin >> hotelNights;
    
    cout << "Enter number of people sharing the trip: ";
    cin >> people;
    
    // calulations
    double gasCost = calculateGasCost(totalMiles, milesPerGallon, gasPrice);
    double foodCost = calculateFoodCost(travelDays, foodBudgetPerDay);
    double hotelCost = calculateHotelCost(hotelNights, hotelCostPerNight);
    
    double totalTripCost = gasCost + foodCost + hotelCost;
    double costPerPerson = totalTripCost / people;
    
    // output
    cout << fixed << setprecision(2);
    
    cout << "\n---Road Trip Summary ---\n";
    cout << "Gas Cost: $" << gasCost << endl;
    cout << "Food Cost: $" <<foodCost << endl;
    cout << "Hotel Cost: $" <<hotelCost << endl;
    cout << "Total Trip Cost: $" <<totalTripCost << endl;
    cout << "Cost Per Person: $" <<costPerPerson << endl;
    
    return 0;
}